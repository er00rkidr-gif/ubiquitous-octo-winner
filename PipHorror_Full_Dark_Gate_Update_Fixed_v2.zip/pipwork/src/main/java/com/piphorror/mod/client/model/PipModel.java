package com.piphorror.mod.client.model;

import com.piphorror.mod.client.renderer.PipRenderer;
import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;

/**
 * One skeleton / one skin for both Pip variants. The "fake" Pip is simply Pip with Jerry eyes:
 * big wide unblinking eyes with tiny pupils that lock onto the player.
 */
public class PipModel extends GeoModel<PipChatListener> {
    private static final ResourceLocation MODEL = new ResourceLocation("piphorror", "geo/friendly_pip.geo.json");
    private static final ResourceLocation TEXTURE = new ResourceLocation("piphorror", "textures/entity/friendly_pip.png");
    private static final ResourceLocation ANIMATION = new ResourceLocation("piphorror", "animations/pip.animation.json");

    // ---- tweak the Jerry eyes here -------------------------------------------------------------
    private static final float JERRY_EYE_SCALE = 1.30F;     // eyeball size (1.0 = normal Pip)
    private static final float JERRY_PUPIL_SCALE = 0.55F;   // pupil size (smaller = creepier)
    private static final float PUPIL_MAX_YAW = 38.0F;       // how far a pupil may swing sideways (degrees)
    private static final float PUPIL_MAX_PITCH = 30.0F;
    private static final float JERRY_MAX_YAW = 48.0F;

    // eye centre relative to the model origin, in blocks (matches the OBJ), baked space: model-left = -x
    private static final float EYE_X = 0.106F;
    private static final float EYE_Y = 0.70F;
    private static final float EYE_Z = -0.147F;

    @Override
    public ResourceLocation getModelResource(PipChatListener animatable) {
        return animatable.isMonsterForm()
            ? new ResourceLocation("piphorror", "geo/pip_monster.geo.json") : MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(PipChatListener animatable) {
        return animatable.isMonsterForm()
            ? new ResourceLocation("piphorror", "textures/entity/pip_monster.png") : TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(PipChatListener animatable) {
        return animatable.isMonsterForm()
            ? new ResourceLocation("piphorror", "animations/pip_monster.animation.json") : ANIMATION;
    }

    @Override
    public void setCustomAnimations(PipChatListener pip, long instanceId, AnimationState<PipChatListener> state) {
        super.setCustomAnimations(pip, instanceId, state);

        CoreGeoBone body = getAnimationProcessor().getBone("body");
        CoreGeoBone head = getAnimationProcessor().getBone("head");
        CoreGeoBone eyeL = getAnimationProcessor().getBone("eye_L");
        CoreGeoBone eyeR = getAnimationProcessor().getBone("eye_R");
        if (pip.isMonsterForm()) {
            return; // monster movement is driven by its own animation file
        }
        CoreGeoBone pupilL = getAnimationProcessor().getBone("pupil_L");
        CoreGeoBone pupilR = getAnimationProcessor().getBone("pupil_R");
        CoreGeoBone dotL = getAnimationProcessor().getBone("pupil_dot_L");
        CoreGeoBone dotR = getAnimationProcessor().getBone("pupil_dot_R");
        if (body == null || head == null || pupilL == null || pupilR == null) {
            return;
        }

        float pt = state.getPartialTick();
        boolean asleep = pip.isDormant();
        boolean jerry = pip.isFakePip() && !asleep;
        boolean refusingToLook = pip.isIgnoringPlayer() || jerry;

        // Fake Pip never turns its head or body toward the player. Only the pupils move.
        if (!asleep && !refusingToLook) {
            float headYaw = Mth.rotLerp(pt, pip.yHeadRotO, pip.yHeadRot);
            float bodyYaw = Mth.rotLerp(pt, pip.yBodyRotO, pip.yBodyRot);
            float netYaw = Mth.clamp(Mth.wrapDegrees(headYaw - bodyYaw), -70.0F, 70.0F);
            float pitch = Mth.clamp(Mth.lerp(pt, pip.xRotO, pip.getXRot()), -40.0F, 40.0F);
            // vanilla: +yaw = turn right, +pitch = look down. Baked model: +rotY = turn left, +rotX = look up.
            head.setRotY(head.getRotY() - netYaw * Mth.DEG_TO_RAD);
            head.setRotX(head.getRotX() - pitch * Mth.DEG_TO_RAD);
        }

        // ---- 2) Jerry eyes: big, unblinking, tiny pupils ---------------------------------------
        if (jerry) {
            for (CoreGeoBone eye : new CoreGeoBone[] {eyeL, eyeR}) {
                if (eye != null) {
                    eye.setScaleX(JERRY_EYE_SCALE);
                    eye.setScaleY(JERRY_EYE_SCALE);
                    eye.setScaleZ(JERRY_EYE_SCALE);
                }
            }
            for (CoreGeoBone dot : new CoreGeoBone[] {dotL, dotR}) {
                if (dot != null) {
                    dot.setScaleX(JERRY_PUPIL_SCALE);
                    dot.setScaleY(JERRY_PUPIL_SCALE);
                }
            }
        }

        // ---- 3) pupils look at the local player at all times -----------------------------------
        Player viewer = Minecraft.getInstance().player;
        if (asleep || viewer == null || (pip.isIgnoringPlayer() && !jerry)) {
            pupilL.setRotX(0);
            pupilL.setRotY(0);
            pupilR.setRotX(0);
            pupilR.setRotY(0);
            return;
        }

        float bodyYawDeg = Mth.rotLerp(pt, pip.yBodyRotO, pip.yBodyRot);
        // model -> world is a rotation about Y by (180 - bodyYaw); we need the inverse for directions
        float toWorld = (float) Math.toRadians(180.0F - bodyYawDeg);

        Vec3 pipPos = new Vec3(Mth.lerp(pt, pip.xo, pip.getX()), Mth.lerp(pt, pip.yo, pip.getY()), Mth.lerp(pt, pip.zo, pip.getZ()));
        Vec3 target = viewer.getEyePosition(pt);

        // combined orientation of body * head (both baked: rotation order Z, Y, X)
        Quaternionf qBody = new Quaternionf().rotationZYX(body.getRotZ(), body.getRotY(), body.getRotX());
        Quaternionf qHead = new Quaternionf().rotationZYX(head.getRotZ(), head.getRotY(), head.getRotX());
        Quaternionf chain = new Quaternionf(qBody).mul(qHead).invert();

        float maxYaw = jerry ? JERRY_MAX_YAW : PUPIL_MAX_YAW;
        aimPupil(pupilL, -EYE_X, pipPos, target, toWorld, chain, maxYaw);
        aimPupil(pupilR, EYE_X, pipPos, target, toWorld, chain, maxYaw);
    }

    private static void aimPupil(CoreGeoBone pupil, float eyeX, Vec3 pipPos, Vec3 target, float toWorld,
                                 Quaternionf inverseChain, float maxYawDeg) {
        float s = PipRenderer.MODEL_SCALE;
        // eye position in the world
        Vector3f eyeOffset = new Vector3f(eyeX * s, EYE_Y * s, EYE_Z * s).rotateY(toWorld);
        float dx = (float) (target.x - (pipPos.x + eyeOffset.x));
        float dy = (float) (target.y - (pipPos.y + eyeOffset.y));
        float dz = (float) (target.z - (pipPos.z + eyeOffset.z));

        // world direction -> model-local direction -> head-local direction
        Vector3f dir = new Vector3f(dx, dy, dz).rotateY(-toWorld);
        inverseChain.transform(dir);
        float horizontal = (float) Math.sqrt(dir.x * dir.x + dir.z * dir.z);

        // model front is -Z: rotY = atan2(-x, -z) (positive = toward model-left), rotX = elevation (positive = up)
        float yaw = (float) Math.toDegrees(Math.atan2(-dir.x, -dir.z));
        float pitch = (float) Math.toDegrees(Math.atan2(dir.y, horizontal));
        yaw = Mth.clamp(yaw, -maxYawDeg, maxYawDeg);
        pitch = Mth.clamp(pitch, -PUPIL_MAX_PITCH, PUPIL_MAX_PITCH);
        pupil.setRotY(yaw * Mth.DEG_TO_RAD);
        pupil.setRotX(pitch * Mth.DEG_TO_RAD);
    }
}
