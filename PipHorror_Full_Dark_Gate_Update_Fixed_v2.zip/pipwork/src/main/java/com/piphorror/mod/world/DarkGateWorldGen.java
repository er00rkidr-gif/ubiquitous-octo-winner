package com.piphorror.mod.world;

import com.google.gson.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;

/** Places the player's first-world Dark Gate landmark once per Overworld. */
@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DarkGateWorldGen {
    private static final String DATA_KEY = "piphorror_dark_gate_worldgen";
    private static final Gson GSON = new Gson();

    private DarkGateWorldGen() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ServerLevel level = player.server.overworld();
        GateData data = level.getDataStorage().computeIfAbsent(GateData::load, GateData::new, DATA_KEY);
        if (data.generated) return;
        BlockPos playerPos = player.blockPosition();
        int x = playerPos.getX() + 32;
        int z = playerPos.getZ() + 4;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos origin = new BlockPos(x - 12, y, z - 8);
        placeGate(level, origin);
        placeLootChests(level, origin);
        placeRuinedSettlement(level, origin);
        data.generated = true;
        data.setDirty();
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal("§5[Pip Horror] §7A dark gate has appeared nearby. Something was left in the chests..."));
    }

    private static void placeGate(ServerLevel level, BlockPos origin) {
        try (InputStream in = DarkGateWorldGen.class.getResourceAsStream("/data/piphorror/structures/dark_gate_blocks.json")) {
            if (in == null) return;
            JsonArray blocks = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement element : blocks) {
                JsonObject b = element.getAsJsonObject();
                ResourceLocation id = new ResourceLocation(b.get("name").getAsString());
                Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(Blocks.AIR);
                if (block == Blocks.AIR || block == Blocks.NETHER_PORTAL) continue;
                BlockState state = block.defaultBlockState();
                JsonObject props = b.getAsJsonObject("properties");
                for (Map.Entry<String, JsonElement> prop : props.entrySet()) {
                    setProperty(state, prop.getKey(), prop.getValue().getAsString());
                }
                BlockPos pos = origin.offset(b.get("x").getAsInt(), b.get("y").getAsInt(), b.get("z").getAsInt());
                level.setBlock(pos, state, 3);
            }
        } catch (Exception ex) {
            System.err.println("[Pip Horror] Could not place Dark Gate schematic: " + ex.getMessage());
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void setProperty(BlockState state, String name, String value) {
        for (Property property : state.getProperties()) {
            if (property.getName().equals(name)) {
                Optional parsed = property.getValue(value);
                if (parsed.isPresent()) state.setValue(property, (Comparable) parsed.get());
                return;
            }
        }
    }

    private static void placeLootChests(ServerLevel level, BlockPos o) {
        BlockPos[] positions = {o.offset(-3, 0, -3), o.offset(3, 0, -3), o.offset(-3, 0, 3), o.offset(3, 0, 3)};
        for (int i = 0; i < positions.length; i++) {
            BlockPos p = positions[i];
            level.setBlock(p, Blocks.CHEST.defaultBlockState(), 3);
            BlockEntity be = level.getBlockEntity(p);
            if (be instanceof ChestBlockEntity chest) fillChest(chest, i);
        }
    }

    private static void fillChest(ChestBlockEntity chest, int variant) {
        chest.setItem(0, enchanted(Items.NETHERITE_SWORD, Enchantments.SHARPNESS, 7, Enchantments.UNBREAKING, 5, Enchantments.FIRE_ASPECT, 2));
        chest.setItem(1, enchanted(Items.NETHERITE_CHESTPLATE, Enchantments.ALL_DAMAGE_PROTECTION, 5, Enchantments.UNBREAKING, 5, Enchantments.MENDING, 1));
        chest.setItem(2, enchanted(Items.NETHERITE_PICKAXE, Enchantments.BLOCK_EFFICIENCY, 7, Enchantments.BLOCK_FORTUNE, 4, Enchantments.UNBREAKING, 5));
        chest.setItem(3, new ItemStack(Items.TOTEM_OF_UNDYING, 2 + variant));
        chest.setItem(4, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 2 + variant));
        chest.setItem(5, new ItemStack(Items.DIAMOND_BLOCK, 4 + variant));
        chest.setItem(6, enchanted(Items.BOW, Enchantments.POWER_ARROWS, 6, Enchantments.INFINITY_ARROWS, 1, Enchantments.UNBREAKING, 4));
        chest.setItem(7, new ItemStack(Items.ELYTRA));
        chest.setChanged();
    }

    private static ItemStack enchanted(net.minecraft.world.item.Item item, Object... enchantments) {
        ItemStack stack = new ItemStack(item);
        for (int i = 0; i + 1 < enchantments.length; i += 2) {
            stack.enchant((net.minecraft.world.item.enchantment.Enchantment) enchantments[i], (Integer) enchantments[i + 1]);
        }
        return stack;
    }

    private static void placeRuinedSettlement(ServerLevel level, BlockPos o) {
        buildRuinedHut(level, o.offset(25, 0, -3));
        buildResearchOutpost(level, o.offset(-24, 0, -5));
    }

    private static void buildRuinedHut(ServerLevel level, BlockPos p) {
        // Small, damaged 9x7 abandoned cottage beside the gate.
        for (int x = 0; x < 9; x++) for (int z = 0; z < 7; z++) {
            level.setBlock(p.offset(x, 0, z), Blocks.COBBLESTONE.defaultBlockState(), 3);
            if (x == 0 || x == 8 || z == 0 || z == 6) {
                for (int y = 1; y <= 3; y++) {
                    if (!((x == 0 || x == 8) && y == 3 && z % 2 == 0))
                        level.setBlock(p.offset(x, y, z), (y == 1 ? Blocks.MOSSY_COBBLESTONE : Blocks.CRACKED_STONE_BRICKS).defaultBlockState(), 3);
                }
            }
        }
        for (int x = 1; x < 8; x++) for (int z = 1; z < 6; z++)
            if ((x + z) % 3 != 0) level.setBlock(p.offset(x, 4, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
        level.setBlock(p.offset(4, 1, 0), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(p.offset(2, 2, 2), Blocks.COBWEB.defaultBlockState(), 3);
        level.setBlock(p.offset(6, 2, 4), Blocks.COBWEB.defaultBlockState(), 3);
        level.setBlock(p.offset(4, 1, 3), Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity be = level.getBlockEntity(p.offset(4, 1, 3));
        if (be instanceof ChestBlockEntity chest) {
            chest.setItem(0, new ItemStack(Items.WRITTEN_BOOK));
            chest.setItem(1, new ItemStack(Items.BREAD, 5));
            chest.setItem(2, new ItemStack(Items.IRON_INGOT, 12));
            chest.setChanged();
        }
    }

    private static void buildResearchOutpost(ServerLevel level, BlockPos p) {
        for (int x = 0; x < 7; x++) for (int z = 0; z < 7; z++) {
            if (x == 0 || x == 6 || z == 0 || z == 6) {
                for (int y = 1; y <= 4; y++) {
                    if (!(y == 2 && (x == 3 || z == 3)))
                        level.setBlock(p.offset(x, y, z), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
                }
            }
        }
        for (int x = 0; x < 7; x++) for (int z = 0; z < 7; z++)
            if ((x + z) % 2 == 0) level.setBlock(p.offset(x, 5, z), Blocks.DARK_OAK_PLANKS.defaultBlockState(), 3);
        level.setBlock(p.offset(3, 1, 3), Blocks.BARREL.defaultBlockState(), 3);
        level.setBlock(p.offset(2, 1, 2), Blocks.COBWEB.defaultBlockState(), 3);
        level.setBlock(p.offset(4, 1, 4), Blocks.COBWEB.defaultBlockState(), 3);
    }

    public static class GateData extends SavedData {
        public boolean generated;
        public static GateData load(CompoundTag tag) { GateData d = new GateData(); d.generated = tag.getBoolean("Generated"); return d; }
        @Override public CompoundTag save(CompoundTag tag) { tag.putBoolean("Generated", generated); return tag; }
    }
}
