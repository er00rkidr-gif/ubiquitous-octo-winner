package com.piphorror.mod.ai;

import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;
import java.util.Map;

public class PipEventDirector {
    private static final Map<String, String> ITEM_ALIASES = Map.ofEntries(
        Map.entry("wood", "oak_log"),
        Map.entry("logs", "oak_log"),
        Map.entry("steak", "cooked_beef"),
        Map.entry("food", "cooked_beef"),
        Map.entry("gold", "gold_ingot"),
        Map.entry("iron", "iron_ingot"),
        Map.entry("copper", "copper_ingot"),
        Map.entry("coal", "coal"),
        Map.entry("stone", "cobblestone"),
        Map.entry("rock", "cobblestone"),
        Map.entry("torch", "torch"),
        Map.entry("torches", "torch"),
        Map.entry("sword", "iron_sword"),
        Map.entry("pickaxe", "iron_pickaxe"),
        Map.entry("axe", "iron_axe")
    );

    public static Item resolveItemByName(String rawQuery) {
        if (rawQuery == null || rawQuery.isBlank()) {
            return Items.AIR;
        }
        String clean = rawQuery.toLowerCase(Locale.ROOT)
            .replaceAll("[^a-z0-9_\\s]", " ")
            .replaceAll("\\s+", " ")
            .trim();

        String alias = ITEM_ALIASES.get(clean);
        if (alias != null) {
            Item aliased = BuiltInRegistries.ITEM.getOptional(new ResourceLocation("minecraft", alias)).orElse(Items.AIR);
            if (aliased != Items.AIR) return aliased;
        }

        String slug = clean.replace(" ", "_");
        Item exact = BuiltInRegistries.ITEM.getOptional(new ResourceLocation("minecraft", slug)).orElse(Items.AIR);
        if (exact != Items.AIR) {
            return exact;
        }

        // Try singular form if plural ("diamonds" -> "diamond", "apples" -> "apple")
        if (slug.endsWith("es") && slug.length() > 3) {
            Item singularEs = BuiltInRegistries.ITEM.getOptional(new ResourceLocation("minecraft", slug.substring(0, slug.length() - 2))).orElse(Items.AIR);
            if (singularEs != Items.AIR) return singularEs;
        }
        if (slug.endsWith("s") && slug.length() > 2) {
            Item singularS = BuiltInRegistries.ITEM.getOptional(new ResourceLocation("minecraft", slug.substring(0, slug.length() - 1))).orElse(Items.AIR);
            if (singularS != Items.AIR) return singularS;
        }

        // Fallback partial word search across registered Minecraft items
        String[] tokens = clean.split(" ");
        Item best = Items.AIR;
        int bestScore = 0;
        for (ResourceLocation key : BuiltInRegistries.ITEM.keySet()) {
            String path = key.getPath();
            int score = 0;
            for (String tok : tokens) {
                if (tok.length() >= 2 && path.contains(tok)) {
                    score += tok.length();
                }
            }
            if (score > bestScore && score >= clean.replace(" ", "").length() / 2) {
                bestScore = score;
                best = BuiltInRegistries.ITEM.get(key);
            }
        }
        return best;
    }

    public static boolean executeEvent(ServerLevel level, ServerPlayer target, PipChatListener pip, String eventKey) {
        if (level == null || target == null || pip == null) {
            return false;
        }

        switch (eventKey) {
            case "lights_flicker" -> {
                pip.triggerTimedState(PipChatListener.STATE_SUMMON, 100);
                pip.revealJerryBriefly(100);
                extinguishNearbyLights(level, target.blockPosition(), 12);
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 90, 0, false, false));
                level.playSound(null, target.blockPosition(), SoundEvents.CANDLE_EXTINGUISH, SoundSource.HOSTILE, 1.2F, 0.55F);
            }
            case "stalk_behind" -> {
                pip.startStalkPeekTask(target, false);
            }
            case "door_knock" -> {
                pip.triggerTimedState(PipChatListener.STATE_PEEK, 90);
                triggerNearestDoorKnock(level, target.blockPosition(), 16);
            }
            case "mimic_whisper" -> {
                pip.triggerTimedState(PipChatListener.STATE_LOOKOUT_LISTEN, 90);
                level.playSound(null, target.blockPosition(), SoundEvents.AMBIENT_CAVE.value(), SoundSource.HOSTILE, 1.0F, 0.65F);
                target.displayClientMessage(Component.literal("§4Pip heard you..."), true);
            }
            case "hunt_escalation" -> {
                pip.revealJerryBriefly(200);
                pip.triggerTimedState(PipChatListener.STATE_HUNT, 200);
                pip.getNavigation().moveTo(target, 1.48D);
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0, false, false));
                level.playSound(null, pip.blockPosition(), SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.3F, 0.55F);
            }
            case "hallucination_decoy" -> {
                BlockPos[] spots = PipChatListener.findBestTreeOrBlockCover(level, target, true);
                BlockPos peekSpot = spots[0];
                pip.teleportTo(peekSpot.getX() + 0.5D, peekSpot.getY(), peekSpot.getZ() + 0.5D);
                pip.getNavigation().stop();
                pip.getLookControl().setLookAt(target, 90.0F, 90.0F);
                pip.revealJerryBriefly(120);
                pip.triggerTimedState(PipChatListener.STATE_PEEK, 120);
                level.sendParticles(ParticleTypes.SOUL, peekSpot.getX() + 0.5D, peekSpot.getY() + 1.8D, peekSpot.getZ() + 0.5D, 24, 0.4D, 0.6D, 0.4D, 0.02D);
                level.playSound(null, peekSpot, SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, 0.95F, 0.55F);
            }

            default -> {
                return false;
            }
        }
        return true;
    }

    /**
     * Finds an actual solid wall / tree / corner block near the player and returns a safe standing
     * position tucked behind/around its edge so Pip visibly peeks out from behind real world blocks.
     */
    private static BlockPos findCoverPeekSpot(ServerLevel level, ServerPlayer player, boolean preferInFront) {
        BlockPos pPos = player.blockPosition();
        Vec3 forward = new Vec3(player.getLookAngle().x, 0, player.getLookAngle().z).normalize();
        if (forward.lengthSqr() < 0.01D) {
            forward = new Vec3(0, 0, 1);
        }

        BlockPos bestSpot = null;
        double bestScore = -Double.MAX_VALUE;

        for (int dx = -14; dx <= 14; dx++) {
            for (int dz = -14; dz <= 14; dz++) {
                double distSq = dx * dx + dz * dz;
                if (distSq < 16 || distSq > 196) continue;

                BlockPos wallBase = new BlockPos(pPos.getX() + dx, pPos.getY(), pPos.getZ() + dz);
                // Adjust to local terrain surface height
                int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, wallBase.getX(), wallBase.getZ()) - 1;
                if (Math.abs(surfaceY - pPos.getY()) > 4) continue;
                wallBase = new BlockPos(wallBase.getX(), pPos.getY(), wallBase.getZ());

                // Look for a 2+ block tall cover pillar / wall / trunk
                if (!level.getBlockState(wallBase).isSolid() || !level.getBlockState(wallBase.above()).isSolid()) {
                    continue;
                }

                // Check adjacent corner tiles to stand behind/beside that cover block
                for (Direction dir : Direction.Plane.HORIZONTAL) {
                    BlockPos hidePos = wallBase.relative(dir);
                    if (!isSafeStandPos(level, hidePos)) continue;

                    Vec3 toHide = new Vec3(hidePos.getX() + 0.5D - player.getX(), 0, hidePos.getZ() + 0.5D - player.getZ()).normalize();
                    double alignment = toHide.dot(forward);
                    double dist = Math.sqrt(distSq);

                    // Score higher when outside center look-cone (or in front corner for decoy) and close (~6-9 blocks)
                    double dirScore = preferInFront ? (alignment * 3.0D) : (-alignment * 4.0D);
                    double distScore = -Math.abs(dist - 7.5D) * 0.45D;
                    // Bonus if the cover block stands between player and hidePos
                    Vec3 coverVec = new Vec3(wallBase.getX() - player.getX(), 0, wallBase.getZ() - player.getZ()).normalize();
                    double coverBonus = coverVec.dot(toHide) > 0.7D ? 2.5D : 0.0D;

                    double total = dirScore + distScore + coverBonus;
                    if (total > bestScore) {
                        bestScore = total;
                        bestSpot = hidePos.immutable();
                    }
                }
            }
        }

        if (bestSpot != null) {
            return bestSpot;
        }

        // Safe surface fallback behind player
        Vec3 fallbackVec = preferInFront
            ? player.position().add(forward.scale(7.5D))
            : player.position().subtract(forward.scale(5.5D));
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(fallbackVec.x), (int) Math.floor(fallbackVec.z));
        return new BlockPos((int) Math.floor(fallbackVec.x), y, (int) Math.floor(fallbackVec.z));
    }

    private static boolean isSafeStandPos(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos.below()).isSolid()
            && !level.getBlockState(pos).isSolid()
            && !level.getBlockState(pos.above()).isSolid();
    }

    private static void extinguishNearbyLights(ServerLevel level, BlockPos center, int radius) {
        BlockPos.betweenClosedStream(center.offset(-radius, -4, -radius), center.offset(radius, 5, radius))
            .forEach(pos -> {
                BlockState state = level.getBlockState(pos);
                if (state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH) || state.is(Blocks.LANTERN)) {
                    level.destroyBlock(pos, true);
                }
            });
    }

    private static void triggerNearestDoorKnock(ServerLevel level, BlockPos center, int radius) {
        BlockPos doorHit = BlockPos.betweenClosedStream(center.offset(-radius, -3, -radius), center.offset(radius, 4, radius))
            .filter(pos -> level.getBlockState(pos).getBlock() instanceof DoorBlock)
            .findFirst()
            .orElse(null);

        if (doorHit != null) {
            level.playSound(null, doorHit, SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, SoundSource.BLOCKS, 1.2F, 0.75F);
            BlockState state = level.getBlockState(doorHit);
            if (state.getBlock() instanceof DoorBlock door) {
                door.setOpen(null, level, state, doorHit, !state.getValue(DoorBlock.OPEN));
            }
        } else {
            level.playSound(null, center.offset(2, 0, 2), SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, SoundSource.BLOCKS, 1.0F, 0.65F);
        }
    }
}
