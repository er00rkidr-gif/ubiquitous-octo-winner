package com.piphorror.mod.net;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.ai.PipAiClient;
import com.piphorror.mod.config.PipConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Three tiny packets for the /pip gui screen:
 *   server -> client  OpenGui     (current settings; the API key itself is never sent back)
 *   client -> server  SaveAi      (new settings, optionally run a connection test)
 *   server -> client  TestResult  (one status line shown in the screen)
 */
public class PipNetwork {
    private static final String PROTOCOL = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(PipHorrorMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered = false;

    public static synchronized void register() {
        if (registered) {
            return;
        }
        registered = true;
        int id = 0;
        CHANNEL.registerMessage(id++, OpenGui.class, OpenGui::encode, OpenGui::decode, OpenGui::handle);
        CHANNEL.registerMessage(id++, SaveAi.class, SaveAi::encode, SaveAi::decode, SaveAi::handle);
        CHANNEL.registerMessage(id++, TestResult.class, TestResult::encode, TestResult::decode, TestResult::handle);
    }

    public static void sendOpenGui(ServerPlayer player) {
        PipConfig.ensureLoaded();
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenGui(
            PipConfig.isAiEnabled(), PipConfig.getProvider(), PipConfig.getModel(), PipConfig.getBaseUrl(), PipConfig.hasApiKey()));
    }

    public static void sendSave(boolean enabled, String provider, String apiKey, String model, String baseUrl, boolean test) {
        CHANNEL.sendToServer(new SaveAi(enabled, provider, apiKey, model, baseUrl, test));
    }

    private static boolean mayEdit(ServerPlayer player) {
        return player.hasPermissions(2) || player.server.isSingleplayerOwner(player.getGameProfile());
    }

    // ------------------------------------------------------------------------------------------
    public record OpenGui(boolean enabled, String provider, String model, String baseUrl, boolean hasKey) {
        static void encode(OpenGui m, FriendlyByteBuf b) {
            b.writeBoolean(m.enabled);
            b.writeUtf(m.provider, 64);
            b.writeUtf(m.model, 128);
            b.writeUtf(m.baseUrl, 512);
            b.writeBoolean(m.hasKey);
        }

        static OpenGui decode(FriendlyByteBuf b) {
            return new OpenGui(b.readBoolean(), b.readUtf(64), b.readUtf(128), b.readUtf(512), b.readBoolean());
        }

        static void handle(OpenGui m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.piphorror.mod.client.gui.PipSetupScreen.open(m.enabled, m.provider, m.model, m.baseUrl, m.hasKey)));
            ctx.get().setPacketHandled(true);
        }
    }

    public record SaveAi(boolean enabled, String provider, String apiKey, String model, String baseUrl, boolean test) {
        static void encode(SaveAi m, FriendlyByteBuf b) {
            b.writeBoolean(m.enabled);
            b.writeUtf(m.provider, 64);
            b.writeUtf(m.apiKey, 512);
            b.writeUtf(m.model, 128);
            b.writeUtf(m.baseUrl, 512);
            b.writeBoolean(m.test);
        }

        static SaveAi decode(FriendlyByteBuf b) {
            return new SaveAi(b.readBoolean(), b.readUtf(64), b.readUtf(512), b.readUtf(128), b.readUtf(512), b.readBoolean());
        }

        static void handle(SaveAi m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            ServerPlayer sender = c.getSender();
            c.enqueueWork(() -> {
                if (sender == null) {
                    return;
                }
                if (!mayEdit(sender)) {
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> sender), new TestResult("§cYou need operator permission to change Pip's AI settings."));
                    return;
                }
                PipConfig.saveAiSettings(m.enabled, m.provider, m.apiKey, m.model, m.baseUrl);
                if (m.test) {
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> sender), new TestResult("§7Saved. Testing connection..."));
                    CompletableFuture.runAsync(() -> {
                        String result = PipAiClient.runConnectionTest();
                        sender.server.execute(() -> CHANNEL.send(PacketDistributor.PLAYER.with(() -> sender), new TestResult(result)));
                    });
                } else {
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> sender), new TestResult("§aSaved!"));
                }
            });
            c.setPacketHandled(true);
        }
    }

    public record TestResult(String message) {
        static void encode(TestResult m, FriendlyByteBuf b) {
            b.writeUtf(m.message, 400);
        }

        static TestResult decode(FriendlyByteBuf b) {
            return new TestResult(b.readUtf(400));
        }

        static void handle(TestResult m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.piphorror.mod.client.gui.PipSetupScreen.showStatus(m.message)));
            ctx.get().setPacketHandled(true);
        }
    }
}
