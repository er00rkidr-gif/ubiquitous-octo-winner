package com.piphorror.mod.entity;

import com.piphorror.mod.config.PipConfig;
import com.piphorror.mod.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class PipChatListener extends PathfinderMob implements GeoEntity {
    public static final String STATE_STALK = "idle_stalk";
    public static final String STATE_LOOKOUT_LISTEN = "lookout_listen";
    public static final String STATE_PROWL_WALK = "prowl_walk";
    public static final String STATE_PEEK = "peek_corner";
    public static final String STATE_HUNT = "crawl_hunt";
    public static final String STATE_FAKE_IGNORE = "fake_ignore_stare";
    public static final String STATE_SUMMON = "event_summon";
    public static final String STATE_DORMANT = "dormant";
    public static final String STATE_WAKE = "wake_up";

    private static final String TASK_NONE = "";
    private static final String TASK_GATHER_WOOD = "GATHER_WOOD";
    private static final String TASK_FETCH_ITEM = "FETCH_ITEM";
    private static final String TASK_HUNT_ENTITY = "HUNT_ENTITY";
    private static final String TASK_STALK_PEEK = "STALK_PEEK";

    private static final Map<String, String> ENTITY_ALIASES = Map.ofEntries(
        Map.entry("skelly", "skeleton"),
        Map.entry("zomb", "zombie"),
        Map.entry("creep", "creeper"),
        Map.entry("spidy", "spider"),
        Map.entry("golem", "iron_golem"),
        Map.entry("dragon", "ender_dragon"),
        Map.entry("endy", "enderman"),
        Map.entry("piggy", "pig"),
        Map.entry("dog", "wolf"),
        Map.entry("villager", "villager")
    );

    private static final EntityDataAccessor<String> AI_STATE =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> IS_FAKE_PIP =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> LISTEN_TICKS =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> EVENT_TICKS =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.INT);
    /** Storyline: true while Pip is the motionless "Unknown Corpse" waiting to be fed an axolotl. */
    private static final EntityDataAccessor<Boolean> DORMANT =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> IGNORE_PLAYER =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> MONSTER_FORM =
        SynchedEntityData.defineId(PipChatListener.class, EntityDataSerializers.BOOLEAN);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private UUID ownerUuid;
    private UUID listeningTargetUuid;
    // Story progression is anchored to the day Pip is first awakened and survives world saves.
    private long storyStartDay = -1L;
    private int storyNight = 0;
    private int weirdIgnoreTicks = 0;
    private int storyCheckCooldown = 0;
    private BlockPos homePos;
    private boolean ownerWasSleeping = false;
    private int lakeWashPhase = 0; // 0=idle, 1=walk to water, 2=wash, 3=return home
    private int lakeWashTicks = 0;
    private BlockPos lakeShorePos;
    private BlockPos guardedBedPos;
    private BlockPos bedStandPos;
    private int bedGuardTicks = 0;
    private int bedGuardCooldown = 900;

    // Active autonomous companion task state
    private String activeTask = TASK_NONE;
    private UUID taskOwnerUuid;
    private UUID huntTargetUuid;
    private BlockPos taskTargetPos;
    private BlockPos stalkHidePos;
    private BlockPos stalkPeekPos;
    private int taskPhase = 0;
    private int taskTicks = 0;
    private int attackCooldownTicks = 0;
    private int autoStalkCooldownTicks = 320;
    private int temporaryJerryTicks = 0;
    private ItemStack carriedStack = ItemStack.EMPTY;
    private Item requestedFetchItem = Items.AIR;
    private int requestedFetchCount = 1;

    // Storyline: scripted lines Pip says after waking up
    private record StoryLine(int delayTicks, String text, boolean voiced) {}
    private final ArrayDeque<StoryLine> storyQueue = new ArrayDeque<>();
    private int storyTimer = 0;

    private static final RawAnimation ANIM_LOOKOUT_LISTEN =
        RawAnimation.begin().thenLoop("animation.pip.lookout_listen");
    private static final RawAnimation ANIM_IDLE_STALK =
        RawAnimation.begin().thenLoop("animation.pip.idle_stalk");
    private static final RawAnimation ANIM_PROWL_WALK =
        RawAnimation.begin().thenLoop("animation.pip.prowl_walk");
    private static final RawAnimation ANIM_PEEK_CORNER =
        RawAnimation.begin().thenLoop("animation.pip.peek_corner");
    private static final RawAnimation ANIM_CRAWL_HUNT =
        RawAnimation.begin().thenLoop("animation.pip.crawl_hunt");
    private static final RawAnimation ANIM_FAKE_IGNORE =
        RawAnimation.begin().thenLoop("animation.pip.fake_ignore_stare");
    private static final RawAnimation ANIM_EVENT_SUMMON =
        RawAnimation.begin().thenPlay("animation.pip.event_summon");
    private static final RawAnimation ANIM_DORMANT =
        RawAnimation.begin().thenLoop("animation.pip.dormant");
    private static final RawAnimation ANIM_WAKE =
        RawAnimation.begin().thenPlay("animation.pip.wake_up").thenLoop("animation.pip.idle_stalk");
    private static final RawAnimation ANIM_TALK =
        RawAnimation.begin().thenPlay("animation.pip.talk");
    private static final RawAnimation ANIM_TALK_LONG =
        RawAnimation.begin().thenPlay("animation.pip.talk_long");
    private static final RawAnimation ANIM_MONSTER_IDLE =
        RawAnimation.begin().thenLoop("animation.pip_monster.idle");
    private static final RawAnimation ANIM_MONSTER_WALK =
        RawAnimation.begin().thenLoop("animation.pip_monster.walk");

    public PipChatListener(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setMaxUpStep(1.1F);
        if (this.getNavigation() instanceof GroundPathNavigation groundNav) {
            groundNav.setCanOpenDoors(true);
            groundNav.setCanPassDoors(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 90.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.36D)
            .add(Attributes.ATTACK_DAMAGE, 9.0D)
            .add(Attributes.FOLLOW_RANGE, 80.0D);
    }

    public static boolean canSpawnInWorld(
        EntityType<? extends PathfinderMob> type,
        LevelAccessor level,
        MobSpawnType reason,
        BlockPos pos,
        RandomSource random
    ) {
        if (!Mob.checkMobSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        int nearby = level.getEntitiesOfClass(PipChatListener.class, new AABB(pos).inflate(112.0D)).size();
        return nearby < 2;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(AI_STATE, STATE_STALK);
        this.entityData.define(IS_FAKE_PIP, false);
        this.entityData.define(LISTEN_TICKS, 0);
        this.entityData.define(EVENT_TICKS, 0);
        this.entityData.define(DORMANT, false);
        this.entityData.define(IGNORE_PLAYER, false);
        this.entityData.define(MONSTER_FORM, false);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (IS_FAKE_PIP.equals(key) || DORMANT.equals(key)) {
            this.refreshDimensions();
        }
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        // Both variants are the same little Pip. While dormant Pip lies on its side, so the box is wide and low.
        return isDormant()
            ? EntityDimensions.scalable(1.0F, 0.6F)
            : EntityDimensions.scalable(0.75F, 1.30F);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        // Pip's eyes sit at ~0.70 blocks of model height * 1.4 render scale
        return isDormant() ? dimensions.height * 0.6F : 0.98F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsFakePip", isFakePip());
        tag.putBoolean("Dormant", isDormant());
        tag.putBoolean("IgnorePlayer", isIgnoringPlayer());
        tag.putBoolean("MonsterForm", isMonsterForm());
        tag.putInt("StoryNight", storyNight);
        if (storyStartDay >= 0L) tag.putLong("StoryStartDay", storyStartDay);
        if (homePos != null) tag.putLong("HomePos", homePos.asLong());
        tag.putString("AiState", getAiState());
        if (this.ownerUuid != null) {
            tag.putUUID("OwnerUUID", this.ownerUuid);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("IsFakePip")) {
            setFakePip(tag.getBoolean("IsFakePip"));
        }
        if (tag.contains("Dormant")) {
            this.entityData.set(DORMANT, tag.getBoolean("Dormant"));
            if (isDormant()) {
                this.setNoAi(true);
            }
            this.refreshDimensions();
        }
        if (tag.contains("IgnorePlayer")) this.entityData.set(IGNORE_PLAYER, tag.getBoolean("IgnorePlayer"));
        if (tag.contains("MonsterForm")) this.entityData.set(MONSTER_FORM, tag.getBoolean("MonsterForm"));
        if (tag.contains("StoryNight")) this.storyNight = tag.getInt("StoryNight");
        if (tag.contains("StoryStartDay")) this.storyStartDay = tag.getLong("StoryStartDay");
        if (tag.contains("HomePos")) this.homePos = BlockPos.of(tag.getLong("HomePos"));
        if (tag.contains("AiState")) {
            setAiState(tag.getString("AiState"));
        }
        if (tag.hasUUID("OwnerUUID")) {
            this.ownerUuid = tag.getUUID("OwnerUUID");
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (this.getNavigation() instanceof GroundPathNavigation) {
            this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        }
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 24.0F) {
            @Override
            public boolean canUse() {
                return storyNight < 4 && !isIgnoringPlayer() && !isFakePip()
                    && !hasActiveTask() && !STATE_PEEK.equals(getAiState()) && super.canUse();
            }
        });
        this.goalSelector.addGoal(6, new RandomStrollGoal(this, 0.65D) {
            @Override
            public boolean canUse() {
                return !PipConfig.isPetFollowAlways() && !isListening() && !hasActiveTask() && !STATE_PEEK.equals(getAiState()) && super.canUse();
            }
        });
    }

    public void setOwner(Player player) {
        if (player != null) {
            this.ownerUuid = player.getUUID();
        }
    }

    public Player getOwner() {
        if (this.ownerUuid == null) return null;
        return this.level().getPlayerByUUID(this.ownerUuid);
    }

    public String getAiState() {
        return this.entityData.get(AI_STATE);
    }

    public void setAiState(String state) {
        this.entityData.set(AI_STATE, state);
    }

    public boolean isFakePip() {
        return this.entityData.get(IS_FAKE_PIP);
    }

    public void setFakePip(boolean fake) {
        this.entityData.set(IS_FAKE_PIP, fake);
        this.refreshDimensions();
    }

    public boolean isIgnoringPlayer() {
        return this.entityData.get(IGNORE_PLAYER);
    }

    public boolean isMonsterForm() {
        return this.entityData.get(MONSTER_FORM);
    }

    private void setMonsterForm(boolean monster) {
        this.entityData.set(MONSTER_FORM, monster);
        if (monster) {
            setFakePip(true);
            setAiState(STATE_FAKE_IGNORE);
        }
    }

    public int getStoryNight() {
        return storyNight;
    }

    private void tickStoryProgress(ServerLevel level) {
        if (storyStartDay < 0L) return;
        long elapsed = Math.max(0L, level.getDayTime() / 24000L - storyStartDay);
        int newNight = (int) Math.min(11L, elapsed + 1L);
        if (newNight != storyNight) storyNight = newNight;

        if (elapsed >= 10L && !isMonsterForm()) {
            setMonsterForm(true);
            for (ServerPlayer player : level.players()) {
                if (player.distanceToSqr(this) < 64.0D * 64.0D) {
                    player.sendSystemMessage(Component.literal("§8[Pip] §cThe skinwalker killed the real Pip. §7This thing has been wearing its face."));
                }
            }
            this.playSound(SoundEvents.ENDERMAN_STARE, 1.0F, 0.42F);
        } else if (elapsed >= 4L && !isFakePip()) {
            setFakePip(true);
            setAiState(STATE_FAKE_IGNORE);
        }

        if (elapsed >= 3L && elapsed < 4L && !isFakePip()) {
            if (weirdIgnoreTicks > 0) {
                weirdIgnoreTicks--;
                if (weirdIgnoreTicks == 0) this.entityData.set(IGNORE_PLAYER, false);
            } else if (--storyCheckCooldown <= 0) {
                storyCheckCooldown = 45 + this.random.nextInt(100);
                if (this.random.nextInt(4) == 0) {
                    weirdIgnoreTicks = 50 + this.random.nextInt(100);
                    this.entityData.set(IGNORE_PLAYER, true);
                    this.getNavigation().stop();
                }
            }
        } else if (elapsed < 3L) {
            this.entityData.set(IGNORE_PLAYER, false);
        }
    }

    /** Starts Pip's little face-washing trip after its owner gets out of bed. */
    private void beginLakeWash(ServerLevel level) {
        if (isDormant() || hasActiveTask()) return;
        if (homePos == null) homePos = this.blockPosition();
        lakeShorePos = findNearestLakeShore(level, this.blockPosition(), 36);
        if (lakeShorePos == null) return;
        lakeWashPhase = 1;
        lakeWashTicks = 0;
        this.getNavigation().stop();
        this.setAiState(STATE_PROWL_WALK);
    }

    private BlockPos findNearestLakeShore(ServerLevel level, BlockPos center, int radius) {
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        BlockPos.MutableBlockPos water = new BlockPos.MutableBlockPos();
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                if (x * x + z * z > radius * radius) continue;
                for (int y = -5; y <= 7; y++) {
                    water.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (!level.getFluidState(water).is(FluidTags.WATER)) continue;
                    for (Direction dir : Direction.Plane.HORIZONTAL) {
                        BlockPos shore = water.relative(dir);
                        if (!level.getBlockState(shore).isSolid() || !level.getBlockState(shore.above()).isAir()) continue;
                        double d = shore.distSqr(center);
                        if (d < bestDistance) {
                            bestDistance = d;
                            best = shore.immutable();
                        }
                    }
                }
            }
        }
        return best;
    }

    /** Returns true while Pip is busy washing its face or walking home. */
    private boolean tickLakeWash(ServerLevel level) {
        Player owner = getOwner();
        if (owner != null && owner.isSleeping()) ownerWasSleeping = true;
        else if (ownerWasSleeping) {
            ownerWasSleeping = false;
            beginLakeWash(level);
        }
        if (lakeWashPhase == 0) return false;
        lakeWashTicks++;
        if (lakeWashPhase == 1) {
            if (lakeShorePos == null || lakeWashTicks > 1800) {
                lakeWashPhase = 3;
            } else {
                this.getNavigation().moveTo(lakeShorePos.getX() + 0.5D, lakeShorePos.getY(), lakeShorePos.getZ() + 0.5D, 0.9D);
                if (this.distanceToSqr(lakeShorePos.getX() + 0.5D, lakeShorePos.getY(), lakeShorePos.getZ() + 0.5D) < 4.0D) {
                    this.getNavigation().stop();
                    lakeWashPhase = 2;
                    lakeWashTicks = 0;
                    this.setAiState(STATE_STALK);
                }
            }
            return true;
        }
        if (lakeWashPhase == 2) {
            this.getNavigation().stop();
            if (lakeWashTicks % 16 == 0) {
                level.sendParticles(ParticleTypes.SPLASH, this.getX(), this.getY() + 0.45D, this.getZ(), 3, 0.18D, 0.08D, 0.18D, 0.02D);
            }
            if (lakeWashTicks >= 100) {
                lakeWashPhase = 3;
                lakeWashTicks = 0;
            }
            return true;
        }
        if (lakeWashPhase == 3) {
            if (homePos == null || this.distanceToSqr(homePos.getX() + 0.5D, homePos.getY(), homePos.getZ() + 0.5D) < 4.0D || lakeWashTicks > 1800) {
                this.getNavigation().stop();
                lakeWashPhase = 0;
                lakeShorePos = null;
                return false;
            }
            this.getNavigation().moveTo(homePos.getX() + 0.5D, homePos.getY(), homePos.getZ() + 0.5D, 1.0D);
            return true;
        }
        return false;
    }

    public boolean isGuardingBed(BlockPos pos) {
        return bedGuardTicks > 0 && guardedBedPos != null && guardedBedPos.distManhattan(pos) <= 1;
    }

    private boolean tickBedGuard(ServerLevel level, ServerPlayer owner) {
        if (bedGuardTicks > 0 && guardedBedPos != null && bedStandPos != null) {
            bedGuardTicks--;
            this.getNavigation().moveTo(bedStandPos.getX() + 0.5D, bedStandPos.getY(), bedStandPos.getZ() + 0.5D, 0.8D);
            if (this.distanceToSqr(bedStandPos.getX() + 0.5D, bedStandPos.getY(), bedStandPos.getZ() + 0.5D) < 2.25D) {
                this.getNavigation().stop();
                this.setAiState(STATE_STALK);
            } else {
                this.setAiState(STATE_PROWL_WALK);
            }
            if (bedGuardTicks <= 0) {
                guardedBedPos = null;
                bedStandPos = null;
                bedGuardCooldown = 900 + this.random.nextInt(1200);
            }
            return true;
        }
        if (bedGuardCooldown > 0) bedGuardCooldown--;
        if (bedGuardCooldown <= 0 && owner != null && !isDormant() && !hasActiveTask()) {
            BlockPos bed = findNearbyBed(level, owner.blockPosition(), 12);
            if (bed != null && this.distanceToSqr(owner) < 20.0D * 20.0D) {
                for (Direction direction : Direction.Plane.HORIZONTAL) {
                    BlockPos stand = bed.relative(direction);
                    if (level.getBlockState(stand).isAir() && level.getBlockState(stand.below()).isSolid()) {
                        guardedBedPos = bed;
                        bedStandPos = stand;
                        bedGuardTicks = 180 + this.random.nextInt(240);
                        return true;
                    }
                }
            }
            bedGuardCooldown = 500 + this.random.nextInt(900);
        }
        return false;
    }

    private BlockPos findNearbyBed(ServerLevel level, BlockPos center, int radius) {
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = -radius; x <= radius; x++) for (int y = -3; y <= 3; y++) for (int z = -radius; z <= radius; z++) {
            pos.set(center.getX() + x, center.getY() + y, center.getZ() + z);
            if (level.getBlockState(pos).is(BlockTags.BEDS)) {
                double d = pos.distSqr(center);
                if (d < bestDistance) { bestDistance = d; best = pos.immutable(); }
            }
        }
        return best;
    }

    public void revealJerryBriefly(int ticks) {
        this.temporaryJerryTicks = Math.max(this.temporaryJerryTicks, ticks);
        this.setFakePip(true);
    }

    // ------------------------------------------------------------------------------------------
    // Storyline: Unknown Corpse -> feed an axolotl -> Pip wakes up
    // ------------------------------------------------------------------------------------------
    public boolean isDormant() {
        return this.entityData.get(DORMANT);
    }

    /** Puts Pip into the motionless "Unknown Corpse" pose. Used by the Unknown Corpse item. */
    public void setDormant(boolean dormant) {
        this.entityData.set(DORMANT, dormant);
        this.setNoAi(dormant);
        if (dormant) {
            this.getNavigation().stop();
            this.entityData.set(LISTEN_TICKS, 0);
            this.entityData.set(EVENT_TICKS, 0);
            this.setFakePip(false);
            this.setAiState(STATE_DORMANT);
        }
        this.refreshDimensions();
    }

    /** Called when a player feeds the sleeping Pip a Bucket of Axolotl. */
    public void wakeUp(Player feeder) {
        if (!isDormant() || !(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        setDormant(false);
        storyStartDay = serverLevel.getDayTime() / 24000L;
        storyNight = 1;
        homePos = this.blockPosition();
        this.entityData.set(IGNORE_PLAYER, false);
        this.entityData.set(MONSTER_FORM, false);
        if (feeder != null) {
            setOwner(feeder);
        }
        this.entityData.set(EVENT_TICKS, 56);
        this.setAiState(STATE_WAKE);
        serverLevel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0D, this.getZ(), 7, 0.35D, 0.3D, 0.35D, 0.02D);
        serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + 0.8D, this.getZ(), 10, 0.4D, 0.4D, 0.4D, 0.02D);

        // The big first line is the full voice clip (~3.3 s); the rest are short chirpy babbles.
        speak("Hey I am pip thanks for feeding me that!", ModSounds.PIP_HEY.get(), true);
        storyQueue.clear();
        storyQueue.add(new StoryLine(95, "I was stuck in that chest for sooo long... it was really dark in there.", true));
        storyQueue.add(new StoryLine(85, "But now I can follow you! Tell me \"pip, gather wood\" or \"pip, fetch diamond\"!", true));
        if (PipConfig.getApiKey().isBlank()) {
            storyQueue.add(new StoryLine(90, "(Psst... type §e/pip gui §fif you want me to talk to you for real with an AI brain!)", false));
        }
        storyTimer = storyQueue.peek().delayTicks();
    }

    /** Says a line to every nearby player, with Pip's friendly voice and a mouth-flap animation. */
    public void speak(String line, SoundEvent sound, boolean longClip) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        Component msg = Component.literal("§a[Pip] §f" + line);
        for (ServerPlayer p : serverLevel.players()) {
            if (p.distanceToSqr(this) < 48.0D * 48.0D) {
                p.sendSystemMessage(msg);
            }
        }
        if (sound != null) {
            serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.NEUTRAL, 1.3F,
                0.98F + this.random.nextFloat() * 0.08F);
            this.triggerAnim("voice_controller", longClip ? "talk_long" : "talk");
        }
    }

    /** Short chirpy babble, used whenever Pip says something in chat (AI replies etc.). */
    public void playTalkVoice() {
        if (this.level() instanceof ServerLevel serverLevel && !isFakePip()) {
            serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.PIP_TALK.get(), SoundSource.NEUTRAL,
                1.2F, 0.95F + this.random.nextFloat() * 0.15F);
            this.triggerAnim("voice_controller", "talk");
        }
    }

    private void tickStory() {
        if (storyQueue.isEmpty()) {
            return;
        }
        if (--storyTimer <= 0) {
            StoryLine line = storyQueue.poll();
            speak(line.text(), line.voiced() ? ModSounds.PIP_TALK.get() : null, false);
            storyTimer = storyQueue.isEmpty() ? 0 : storyQueue.peek().delayTicks();
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (isDormant()) {
            ItemStack held = player.getItemInHand(hand);
            if (held.is(Items.AXOLOTL_BUCKET)) {
                if (!this.level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                    }
                    wakeUp(player);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            if (!this.level().isClientSide) {
                player.displayClientMessage(Component.literal("§7It isn't moving... but it looks hungry. Maybe something from the water?"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean isPushable() {
        return !isDormant() && super.isPushable();
    }

    public boolean isListening() {
        return !isFakePip() && (this.entityData.get(LISTEN_TICKS) > 0 || STATE_LOOKOUT_LISTEN.equals(getAiState()));
    }

    public boolean hasActiveTask() {
        return !TASK_NONE.equals(this.activeTask);
    }

    public boolean startLookoutListen(ServerPlayer speaker, int ticks) {
        if (speaker != null && this.ownerUuid == null) {
            setOwner(speaker);
        }
        this.getNavigation().stop();
        if (speaker != null) {
            this.getLookControl().setLookAt(speaker, 50.0F, 50.0F);
        }

        if (this.isFakePip()) {
            this.entityData.set(LISTEN_TICKS, 0);
            this.entityData.set(EVENT_TICKS, ticks);
            this.setAiState(STATE_FAKE_IGNORE);
            this.playSound(SoundEvents.ENDERMAN_STARE, 0.9F, 0.52F);
            return false;
        }

        this.listeningTargetUuid = speaker != null ? speaker.getUUID() : null;
        this.entityData.set(LISTEN_TICKS, ticks);
        this.setAiState(STATE_LOOKOUT_LISTEN);
        this.playSound(SoundEvents.CAT_AMBIENT, 0.75F, 0.85F);
        return true;
    }

    public void returnToFollowOwner(ServerPlayer owner) {
        if (owner != null) {
            setOwner(owner);
            owner.sendSystemMessage(Component.literal("§a[Pip] §7*trots right back to follow beside you!*"));
        }
        clearTask();
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
    }

    public void startGatherWoodTask(ServerPlayer owner) {
        if (!(this.level() instanceof ServerLevel serverLevel) || owner == null) return;
        setOwner(owner);
        this.activeTask = TASK_GATHER_WOOD;
        this.taskOwnerUuid = owner.getUUID();
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.carriedStack = ItemStack.EMPTY;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        this.setAiState(STATE_PROWL_WALK);

        BlockPos treePos = findNearestLogPos(serverLevel, this.blockPosition(), 48);
        if (treePos != null) {
            this.taskTargetPos = treePos;
        } else {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            int tx = this.blockPosition().getX() + (int) Math.round(Math.cos(angle) * 20.0D);
            int tz = this.blockPosition().getZ() + (int) Math.round(Math.sin(angle) * 20.0D);
            int ty = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            this.taskTargetPos = new BlockPos(tx, ty, tz);
        }
        owner.sendSystemMessage(Component.literal("§a[Pip] §7*twitches ear and sprints to chop trees for wood!*"));
    }

    public void startFetchItemTask(ServerPlayer owner, Item item, int count) {
        if (!(this.level() instanceof ServerLevel serverLevel) || owner == null || item == null || item == Items.AIR) return;
        setOwner(owner);
        this.activeTask = TASK_FETCH_ITEM;
        this.taskOwnerUuid = owner.getUUID();
        this.requestedFetchItem = item;
        this.requestedFetchCount = Math.max(1, count);
        this.carriedStack = ItemStack.EMPTY;
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        this.setAiState(STATE_PROWL_WALK);

        List<ItemEntity> dropped = serverLevel.getEntitiesOfClass(
            ItemEntity.class,
            this.getBoundingBox().inflate(48.0D),
            e -> e.isAlive() && e.getItem().is(item)
        );
        if (!dropped.isEmpty()) {
            ItemEntity nearest = dropped.stream()
                .min(Comparator.comparingDouble(e -> e.distanceToSqr(this)))
                .orElse(null);
            this.taskTargetPos = nearest != null ? nearest.blockPosition() : this.blockPosition();
        } else {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            int tx = this.blockPosition().getX() + (int) Math.round(Math.cos(angle) * 16.0D);
            int tz = this.blockPosition().getZ() + (int) Math.round(Math.sin(angle) * 16.0D);
            int ty = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            this.taskTargetPos = new BlockPos(tx, ty, tz);
        }
        String label = new ItemStack(item).getHoverName().getString();
        owner.sendSystemMessage(Component.literal("§a[Pip] §7*scampers off to fetch §e" + label + "§7...*"));
    }

    public boolean startHuntByQuery(ServerPlayer owner, String rawTargetQuery) {
        if (!(this.level() instanceof ServerLevel serverLevel) || owner == null) return false;
        setOwner(owner);
        LivingEntity found = resolveHuntTarget(serverLevel, owner, rawTargetQuery);
        if (found == null) {
            owner.sendSystemMessage(Component.literal("§a[Pip] §7*sniffs the air* I couldn't find any §e" + rawTargetQuery + " §7within 84 blocks!"));
            return false;
        }
        this.activeTask = TASK_HUNT_ENTITY;
        this.taskOwnerUuid = owner.getUUID();
        this.huntTargetUuid = found.getUUID();
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.attackCooldownTicks = 0;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        this.setAiState(STATE_HUNT);
        this.playSound(SoundEvents.CAT_HISS, 1.0F, 0.8F);
        owner.sendSystemMessage(Component.literal("§a[Pip] §c*ears pin back — locking onto §e" + found.getName().getString() + "§c!*"));
        return true;
    }

    public void startStalkPeekTask(ServerPlayer targetPlayer, boolean revealMonster) {
        if (!(this.level() instanceof ServerLevel serverLevel) || targetPlayer == null) return;
        if (this.ownerUuid == null) setOwner(targetPlayer);

        BlockPos[] spots = findBestTreeOrBlockCover(serverLevel, targetPlayer, false);
        this.stalkHidePos = spots[0];
        this.stalkPeekPos = spots[1];
        this.activeTask = TASK_STALK_PEEK;
        this.taskOwnerUuid = targetPlayer.getUUID();
        this.taskPhase = 0; // 0=sneak behind tree/wall, 1=peek out from edge
        this.taskTicks = 0;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        if (revealMonster) {
            revealJerryBriefly(180);
        }
        this.setAiState(STATE_PROWL_WALK);
    }

    public void triggerTimedState(String state, int ticks) {
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, ticks);
        this.setAiState(state);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }

        if (this.attackCooldownTicks > 0) {
            this.attackCooldownTicks--;
        }

        // Storyline: the Unknown Corpse does nothing at all until it is fed.
        if (isDormant()) {
            this.getNavigation().stop();
            if (!STATE_DORMANT.equals(getAiState())) {
                this.setAiState(STATE_DORMANT);
            }
            return;
        }
        tickStory();
        tickStoryProgress(serverLevel);
        if (tickLakeWash(serverLevel)) return;

        // Fake Pip deliberately does not turn its head/body. The client-side model moves only its pupils.

        // Auto-bind to nearest survival/creative player if Pip doesn't have an owner yet
        if (this.ownerUuid == null) {
            Player nearest = serverLevel.getNearestPlayer(this, 64.0D);
            if (nearest != null) {
                this.ownerUuid = nearest.getUUID();
            }
        }

        if (this.temporaryJerryTicks > 0) {
            this.temporaryJerryTicks--;
            if (this.temporaryJerryTicks <= 0 && !hasActiveTask()) {
                this.setFakePip(false);
            }
        }

        // Priority 1: Active command/autonomous task (Hunt, Gather, Fetch, Stalk-Peek)
        if (hasActiveTask()) {
            tickAutonomousTask(serverLevel);
            return;
        }

        // Priority 2: Listening lockout pose
        int listenTicks = this.entityData.get(LISTEN_TICKS);
        if (listenTicks > 0) {
            this.getNavigation().stop();
            Player speaker = this.listeningTargetUuid != null ? serverLevel.getPlayerByUUID(this.listeningTargetUuid) : getOwner();
            if (speaker != null) {
                this.getLookControl().setLookAt(speaker, 40.0F, 40.0F);
            }
            this.entityData.set(LISTEN_TICKS, listenTicks - 1);
            if (listenTicks - 1 <= 0 && STATE_LOOKOUT_LISTEN.equals(getAiState())) {
                this.setAiState(STATE_STALK);
                this.listeningTargetUuid = null;
            }
            return;
        }

        // Priority 3: Timed event state
        int eventTicks = this.entityData.get(EVENT_TICKS);
        if (eventTicks > 0) {
            this.entityData.set(EVENT_TICKS, eventTicks - 1);
            if (eventTicks - 1 <= 0 && !isListening()) {
                this.setAiState(STATE_STALK);
            }
            return;
        }

        // Priority 4: Occasional smart stalking behind nearest tree/wall even while being a loyal pet
        Player owner = getOwner();
        if (owner instanceof ServerPlayer serverOwner) {
            if (tickBedGuard(serverLevel, serverOwner)) return;
            if (PipConfig.isAutoStalkTrees()) {
                this.autoStalkCooldownTicks--;
                if (this.autoStalkCooldownTicks <= 0) {
                    this.autoStalkCooldownTicks = PipConfig.getStalkCooldownTicks() + this.random.nextInt(260);
                    if (this.distanceToSqr(serverOwner) < 400.0D && !isFakePip()) {
                        startStalkPeekTask(serverOwner, false);
                        return;
                    }
                }
            }

            // Priority 5: Pet Follow All The Time!
            if (PipConfig.isPetFollowAlways()) {
                tickPetFollow(serverLevel, serverOwner);
            }
        }
    }

    private void tickPetFollow(ServerLevel level, ServerPlayer owner) {
        if (owner.isSpectator()) return;
        double followDist = PipConfig.getFollowDistance();
        double distSq = this.distanceToSqr(owner);

        // Teleport safely near owner if separated by > 26 blocks
        if (distSq > 676.0D) {
            Vec3 behind = owner.position().subtract(owner.getLookAngle().scale(3.0D));
            int tx = (int) Math.floor(behind.x);
            int tz = (int) Math.floor(behind.z);
            int ty = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            if (Math.abs(ty - owner.getY()) <= 8) {
                this.getNavigation().stop();
                this.teleportTo(tx + 0.5D, ty, tz + 0.5D);
                this.setAiState(STATE_STALK);
                return;
            }
        }

        if (distSq > followDist * followDist) {
            double speed = distSq > 100.0D ? 1.38D : 1.12D;
            this.getNavigation().moveTo(owner, speed);
            if (!isFakePip() && !isIgnoringPlayer()) this.getLookControl().setLookAt(owner, 35.0F, 35.0F);
            this.setAiState(STATE_PROWL_WALK);
        } else {
            if (distSq < 4.5D) {
                this.getNavigation().stop();
            }
            if (!isFakePip() && !isIgnoringPlayer()) this.getLookControl().setLookAt(owner, 25.0F, 25.0F);
            if (!STATE_STALK.equals(getAiState())) {
                this.setAiState(STATE_STALK);
            }
        }
    }

    private void tickAutonomousTask(ServerLevel level) {
        this.taskTicks++;
        Player rawOwner = this.taskOwnerUuid != null ? level.getPlayerByUUID(this.taskOwnerUuid) : getOwner();
        if (!(rawOwner instanceof ServerPlayer owner)) {
            clearTask();
            return;
        }

        if (TASK_HUNT_ENTITY.equals(this.activeTask)) {
            tickHuntTask(level, owner);
            return;
        }
        if (TASK_STALK_PEEK.equals(this.activeTask)) {
            tickStalkPeekTask(level, owner);
            return;
        }

        if (this.taskPhase == 0) {
            this.setAiState(STATE_PROWL_WALK);
            if (this.taskTargetPos != null) {
                this.getNavigation().moveTo(
                    this.taskTargetPos.getX() + 0.5D,
                    this.taskTargetPos.getY(),
                    this.taskTargetPos.getZ() + 0.5D,
                    1.34D
                );
                double distSq = this.distanceToSqr(
                    this.taskTargetPos.getX() + 0.5D,
                    this.taskTargetPos.getY(),
                    this.taskTargetPos.getZ() + 0.5D
                );
                if (distSq <= 10.5D || this.taskTicks >= 110) {
                    this.getNavigation().stop();
                    this.taskPhase = 1;
                    this.taskTicks = 0;
                }
            } else {
                this.taskPhase = 1;
                this.taskTicks = 0;
            }
        } else if (this.taskPhase == 1) {
            this.setAiState(STATE_SUMMON);
            if (this.taskTicks == 15) {
                if (TASK_GATHER_WOOD.equals(this.activeTask)) {
                    this.carriedStack = harvestWoodBundle(level);
                    level.playSound(null, this.blockPosition(), SoundEvents.WOOD_BREAK, SoundSource.NEUTRAL, 1.0F, 1.0F);
                } else if (TASK_FETCH_ITEM.equals(this.activeTask)) {
                    this.carriedStack = collectOrCreateFetchedStack(level);
                    level.playSound(null, this.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.85F, 1.2F);
                }
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + 1.0D, this.getZ(), 8, 0.3D, 0.3D, 0.3D, 0.02D);
            }
            if (this.taskTicks >= 32) {
                this.taskPhase = 2;
                this.taskTicks = 0;
            }
        } else {
            this.setAiState(STATE_PROWL_WALK);
            this.getNavigation().moveTo(owner, 1.40D);
            if (this.taskTicks == 170 && this.distanceToSqr(owner) > 36.0D) {
                Vec3 back = owner.position().add(owner.getLookAngle().scale(3.0D));
                int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) back.x, (int) back.z);
                this.teleportTo(back.x, surfaceY, back.z);
            }
            if (this.distanceToSqr(owner) <= 9.0D || this.taskTicks >= 220) {
                this.getNavigation().stop();
                this.getLookControl().setLookAt(owner, 45.0F, 45.0F);
                deliverCarriedItem(level, owner);
                clearTask();
            }
        }
    }

    private void tickHuntTask(ServerLevel level, ServerPlayer owner) {
        Entity ent = this.huntTargetUuid != null ? level.getEntity(this.huntTargetUuid) : null;
        if (!(ent instanceof LivingEntity target) || !target.isAlive() || this.taskTicks > 600) {
            if (ent instanceof LivingEntity deadTarget && !deadTarget.isAlive()) {
                owner.sendSystemMessage(Component.literal("§a[Pip] §fEliminated §c" + deadTarget.getName().getString() + "§f! Coming right back to you."));
                this.playSound(SoundEvents.CAT_PURREOW, 0.9F, 1.1F);
            } else {
                owner.sendSystemMessage(Component.literal("§a[Pip] §7Target lost — returning to follow you."));
            }
            clearTask();
            return;
        }

        this.setAiState(STATE_HUNT);
        this.getLookControl().setLookAt(target, 60.0F, 60.0F);
        this.getNavigation().moveTo(target, 1.54D);

        double distSq = this.distanceToSqr(target);
        // Smart pounce leap when closing distance
        if (this.onGround() && distSq > 6.5D && distSq < 34.0D && this.taskTicks % 24 == 0) {
            Vec3 lunge = target.position().subtract(this.position()).normalize().scale(0.62D);
            this.setDeltaMovement(lunge.x, 0.34D, lunge.z);
            this.playSound(SoundEvents.CAT_HISS, 0.8F, 1.05F);
        }

        double reach = 2.55D + target.getBbWidth() * 0.7D;
        if (distSq <= reach * reach && this.attackCooldownTicks <= 0) {
            this.attackCooldownTicks = 12;
            this.swing(InteractionHand.MAIN_HAND);
            float dmg = target instanceof Player ? 7.0F : 11.0F;
            target.hurt(this.damageSources().mobAttack(this), dmg);
            level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(), 6, 0.25D, 0.25D, 0.25D, 0.08D);
            this.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.85F, 1.15F);
            if (!target.isAlive()) {
                owner.sendSystemMessage(Component.literal("§a[Pip] §fKilled §c" + target.getName().getString() + "§f! Returning to you."));
                this.playSound(SoundEvents.CAT_PURREOW, 0.95F, 1.15F);
                clearTask();
            }
        }
    }

    private void tickStalkPeekTask(ServerLevel level, ServerPlayer player) {
        if (this.stalkHidePos == null) {
            clearTask();
            return;
        }

        if (this.taskPhase == 0) {
            // Phase 0: Sneak/run to the hiding spot directly behind nearest tree or solid block
            this.setAiState(STATE_PROWL_WALK);
            this.getNavigation().moveTo(this.stalkHidePos.getX() + 0.5D, this.stalkHidePos.getY(), this.stalkHidePos.getZ() + 0.5D, 1.38D);
            double dSq = this.distanceToSqr(this.stalkHidePos.getX() + 0.5D, this.stalkHidePos.getY(), this.stalkHidePos.getZ() + 0.5D);
            if (this.taskTicks == 45 && dSq > 49.0D) {
                // Shadow-step if path around terrain took too long
                this.teleportTo(this.stalkHidePos.getX() + 0.5D, this.stalkHidePos.getY(), this.stalkHidePos.getZ() + 0.5D);
                dSq = 0.0D;
            }
            if (dSq <= 2.4D || this.taskTicks >= 60) {
                this.getNavigation().stop();
                this.taskPhase = 1;
                this.taskTicks = 0;
                level.playSound(null, this.blockPosition(), SoundEvents.CAT_PURR, SoundSource.HOSTILE, 0.75F, 0.55F);
            }
        } else {
            // Phase 1: Slide laterally toward peekEdgePos & lean out around the tree/wall while watching player!
            this.setAiState(STATE_PEEK);
            this.getLookControl().setLookAt(player, 75.0F, 75.0F);
            boolean playerLooking = isPlayerStaringAtMe(player);

            if (playerLooking && this.stalkHidePos != null) {
                // Caught peeking! Duck back behind the tree/block!
                this.getNavigation().moveTo(this.stalkHidePos.getX() + 0.5D, this.stalkHidePos.getY(), this.stalkHidePos.getZ() + 0.5D, 0.95D);
                if (this.taskTicks % 30 == 0) {
                    level.playSound(null, this.blockPosition(), SoundEvents.AZALEA_LEAVES_STEP, SoundSource.NEUTRAL, 0.8F, 0.85F);
                }
            } else if (this.stalkPeekPos != null) {
                // Slowly lean out past the edge of the tree/block to stare
                this.getNavigation().moveTo(this.stalkPeekPos.getX() + 0.5D, this.stalkPeekPos.getY(), this.stalkPeekPos.getZ() + 0.5D, 0.72D);
            }

            if (this.taskTicks >= 130 || this.distanceToSqr(player) < 6.5D) {
                clearTask();
            }
        }
    }

    private boolean isPlayerStaringAtMe(ServerPlayer player) {
        Vec3 look = player.getLookAngle().normalize();
        Vec3 toPip = this.getEyePosition().subtract(player.getEyePosition()).normalize();
        return look.dot(toPip) > 0.88D && this.hasLineOfSight(player);
    }

    private LivingEntity resolveHuntTarget(ServerLevel level, ServerPlayer owner, String rawQuery) {
        if (rawQuery == null || rawQuery.isBlank()) return null;
        String clean = rawQuery.toLowerCase(Locale.ROOT)
            .replaceAll("^(?:a|an|the|that|this|some)\\s+", "")
            .replaceAll("[^a-z0-9_\\s]", " ")
            .replaceAll("\\s+", " ")
            .trim();
        if (clean.isEmpty()) return null;

        String aliased = ENTITY_ALIASES.getOrDefault(clean, clean);
        String slug = aliased.replace(" ", "_");

        // 1. Check online players by exact or partial username
        for (ServerPlayer sp : level.getServer().getPlayerList().getPlayers()) {
            if (sp.level() == level && sp.isAlive() && sp.distanceToSqr(owner) <= 9216.0D) {
                String pName = sp.getName().getString().toLowerCase(Locale.ROOT);
                if (pName.equals(clean) || (!sp.equals(owner) && pName.contains(clean))) {
                    return sp;
                }
            }
        }

        // 2. Check all living entities within 84 blocks
        List<LivingEntity> candidates = level.getEntitiesOfClass(
            LivingEntity.class,
            owner.getBoundingBox().inflate(84.0D),
            e -> e.isAlive() && e != this && e != owner
        );

        LivingEntity best = null;
        double bestScore = -Double.MAX_VALUE;
        for (LivingEntity e : candidates) {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType());
            String typePath = key != null ? key.getPath().toLowerCase(Locale.ROOT) : "";
            String display = e.getName().getString().toLowerCase(Locale.ROOT);

            double match = 0.0D;
            if (typePath.equals(slug) || display.equals(clean)) {
                match = 100.0D;
            } else if (typePath.contains(slug) || display.contains(clean)) {
                match = 60.0D;
            } else if (slug.endsWith("s") && (typePath.equals(slug.substring(0, slug.length() - 1)) || typePath.contains(slug.substring(0, slug.length() - 1)))) {
                match = 50.0D;
            }

            if (match > 0.0D) {
                double distPenalty = Math.sqrt(e.distanceToSqr(this)) * 0.4D;
                double total = match - distPenalty;
                if (total > bestScore) {
                    bestScore = total;
                    best = e;
                }
            }
        }
        return best;
    }

    public static BlockPos[] findBestTreeOrBlockCover(ServerLevel level, ServerPlayer player, boolean preferInFront) {
        BlockPos pPos = player.blockPosition();
        Vec3 forward = new Vec3(player.getLookAngle().x, 0, player.getLookAngle().z).normalize();
        if (forward.lengthSqr() < 0.01D) {
            forward = new Vec3(0, 0, 1);
        }

        BlockPos bestHide = null;
        BlockPos bestPeek = null;
        double bestScore = -Double.MAX_VALUE;

        for (int dx = -18; dx <= 18; dx++) {
            for (int dz = -18; dz <= 18; dz++) {
                double distSq = dx * dx + dz * dz;
                if (distSq < 20 || distSq > 324) continue;

                int wx = pPos.getX() + dx;
                int wz = pPos.getZ() + dz;
                int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, wx, wz) - 1;
                if (Math.abs(groundY - pPos.getY()) > 6) continue;

                // Scan vertical column for 2+ tall tree log or solid wall/block
                BlockPos coverPos = new BlockPos(wx, pPos.getY(), wz);
                boolean isTree = level.getBlockState(coverPos).is(BlockTags.LOGS) || level.getBlockState(coverPos.above()).is(BlockTags.LOGS);
                if (!isTree) {
                    // Check surface-adjusted column too
                    BlockPos surfCover = new BlockPos(wx, groundY + 1, wz);
                    if (level.getBlockState(surfCover).is(BlockTags.LOGS) || (level.getBlockState(surfCover).blocksMotion() && level.getBlockState(surfCover.above()).blocksMotion())) {
                        coverPos = surfCover;
                        isTree = level.getBlockState(surfCover).is(BlockTags.LOGS);
                    } else if (!(level.getBlockState(coverPos).blocksMotion() && level.getBlockState(coverPos.above()).blocksMotion())) {
                        continue;
                    }
                }

                Vec3 coverDir = new Vec3(coverPos.getX() + 0.5D - player.getX(), 0, coverPos.getZ() + 0.5D - player.getZ()).normalize();

                // Evaluate each adjacent ground tile around this tree/block
                for (Direction dir : Direction.Plane.HORIZONTAL) {
                    BlockPos hideCandidate = coverPos.relative(dir);
                    if (!isSafeStandPos(level, hideCandidate)) continue;

                    Vec3 hideOffset = new Vec3(hideCandidate.getX() - coverPos.getX(), 0, hideCandidate.getZ() - coverPos.getZ()).normalize();
                    double behindCover = hideOffset.dot(coverDir); // >0 means directly behind tree/block from player!
                    if (behindCover < 0.15D) continue;

                    // Look for lateral edge tile next to hideCandidate for peeking out
                    Direction leftEdge = dir.getClockWise();
                    Direction rightEdge = dir.getCounterClockWise();
                    BlockPos peekCandidate = isSafeStandPos(level, hideCandidate.relative(leftEdge))
                        ? hideCandidate.relative(leftEdge)
                        : (isSafeStandPos(level, hideCandidate.relative(rightEdge)) ? hideCandidate.relative(rightEdge) : coverPos.relative(leftEdge));

                    Vec3 toHide = new Vec3(hideCandidate.getX() + 0.5D - player.getX(), 0, hideCandidate.getZ() + 0.5D - player.getZ()).normalize();
                    double gazeAlignment = toHide.dot(forward);
                    double dist = Math.sqrt(distSq);

                    double treeBonus = isTree ? 6.5D : 1.5D;
                    double angleScore = preferInFront ? (gazeAlignment * 3.0D) : (-gazeAlignment * 4.5D);
                    double distScore = -Math.abs(dist - 8.5D) * 0.45D;
                    double total = treeBonus + behindCover * 4.0D + angleScore + distScore;

                    if (total > bestScore) {
                        bestScore = total;
                        bestHide = hideCandidate.immutable();
                        bestPeek = isSafeStandPos(level, peekCandidate) ? peekCandidate.immutable() : hideCandidate.immutable();
                    }
                }
            }
        }

        if (bestHide != null) {
            return new BlockPos[]{bestHide, bestPeek != null ? bestPeek : bestHide};
        }

        Vec3 fallback = preferInFront
            ? player.position().add(forward.scale(7.5D))
            : player.position().subtract(forward.scale(6.0D));
        int fy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(fallback.x), (int) Math.floor(fallback.z));
        BlockPos fbPos = new BlockPos((int) Math.floor(fallback.x), fy, (int) Math.floor(fallback.z));
        return new BlockPos[]{fbPos, fbPos};
    }

    private static boolean isSafeStandPos(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos.below()).blocksMotion()
            && !level.getBlockState(pos).blocksMotion()
            && !level.getBlockState(pos.above()).blocksMotion();
    }

    private ItemStack harvestWoodBundle(ServerLevel level) {
        Item logItem = Items.OAK_LOG;
        int broken = 0;
        BlockPos origin = this.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-5, -2, -5), origin.offset(5, 8, 5))) {
            BlockState st = level.getBlockState(p);
            if (st.is(BlockTags.LOGS)) {
                Item blockItem = st.getBlock().asItem();
                if (blockItem != Items.AIR) {
                    logItem = blockItem;
                }
                level.destroyBlock(p, false);
                broken++;
                if (broken >= 6) break;
            }
        }
        int amount = Math.max(16, Math.min(32, 16 + broken * 3));
        return new ItemStack(logItem, amount);
    }

    private ItemStack collectOrCreateFetchedStack(ServerLevel level) {
        List<ItemEntity> matches = level.getEntitiesOfClass(
            ItemEntity.class,
            this.getBoundingBox().inflate(8.0D),
            e -> e.isAlive() && e.getItem().is(this.requestedFetchItem)
        );
        if (!matches.isEmpty()) {
            ItemEntity picked = matches.get(0);
            ItemStack copy = picked.getItem().copy();
            picked.discard();
            return copy;
        }
        int clamped = Math.min(this.requestedFetchCount, Math.max(1, this.requestedFetchItem.getMaxStackSize()));
        return new ItemStack(this.requestedFetchItem, clamped);
    }

    private void deliverCarriedItem(ServerLevel level, Player owner) {
        if (this.carriedStack.isEmpty()) {
            return;
        }
        Vec3 dropPos = owner.position().add(owner.getLookAngle().scale(1.25D));
        ItemEntity drop = new ItemEntity(level, dropPos.x, owner.getY() + 0.35D, dropPos.z, this.carriedStack.copy());
        drop.setNoPickUpDelay();
        level.addFreshEntity(drop);
        this.playSound(SoundEvents.CAT_PURREOW, 0.9F, 1.15F);
        owner.sendSystemMessage(Component.literal(
            "§a[Pip] §fDropped §e" + this.carriedStack.getCount() + "x " + this.carriedStack.getHoverName().getString() + "§f for you!"
        ));
    }

    private void clearTask() {
        this.activeTask = TASK_NONE;
        this.taskOwnerUuid = null;
        this.huntTargetUuid = null;
        this.taskTargetPos = null;
        this.stalkHidePos = null;
        this.stalkPeekPos = null;
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.carriedStack = ItemStack.EMPTY;
        this.requestedFetchItem = Items.AIR;
        this.setAiState(STATE_STALK);
    }

    private static BlockPos findNearestLogPos(ServerLevel level, BlockPos center, int radius) {
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx += 2) {
            for (int dz = -radius; dz <= radius; dz += 2) {
                int x = center.getX() + dx;
                int z = center.getZ() + dz;
                int topY = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                for (int dy = -6; dy <= 4; dy++) {
                    BlockPos p = new BlockPos(x, topY + dy, z);
                    if (level.getBlockState(p).is(BlockTags.LOGS)) {
                        double d = p.distSqr(center);
                        if (d < bestDistSq) {
                            bestDistSq = d;
                            best = p.immutable();
                        }
                        break;
                    }
                }
            }
        }
        return best;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "pip_main_controller", 4, state -> {
            if (isMonsterForm()) {
                return state.setAndContinue(state.isMoving() ? ANIM_MONSTER_WALK : ANIM_MONSTER_IDLE);
            }
            String aiState = getAiState();
            return switch (aiState) {
                case STATE_LOOKOUT_LISTEN -> state.setAndContinue(ANIM_LOOKOUT_LISTEN);
                case STATE_PROWL_WALK -> state.setAndContinue(ANIM_PROWL_WALK);
                case STATE_PEEK -> state.setAndContinue(ANIM_PEEK_CORNER);
                case STATE_HUNT -> state.setAndContinue(ANIM_CRAWL_HUNT);
                case STATE_FAKE_IGNORE -> state.setAndContinue(ANIM_FAKE_IGNORE);
                case STATE_SUMMON -> state.setAndContinue(ANIM_EVENT_SUMMON);
                case STATE_DORMANT -> state.setAndContinue(ANIM_DORMANT);
                case STATE_WAKE -> state.setAndContinue(ANIM_WAKE);
                default -> {
                    if (state.isMoving()) {
                        state.setAndContinue(ANIM_PROWL_WALK);
                    } else {
                        state.setAndContinue(ANIM_IDLE_STALK);
                    }
                    yield PlayState.CONTINUE;
                }
            };
        }));

        // Mouth flaps while Pip talks. Only plays when triggered by speak() / playTalkVoice().
        controllers.add(new AnimationController<>(this, "voice_controller", 2, state -> PlayState.STOP)
            .triggerableAnim("talk", ANIM_TALK)
            .triggerableAnim("talk_long", ANIM_TALK_LONG));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
